# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------
from azure.ai.generative._version import VERSION

USER_AGENT = "{}/{} {}/{}".format("azure-ai-generative", VERSION, "evaluate", VERSION)
