# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------

system_prompt_for_metrics = """You are an AI assistant. You will be given the definition of an evaluation metric for 
assessing the quality of an answer in a question-answering task. Your job is to compute an accurate evaluation score 
using the provided evaluation metric."""
